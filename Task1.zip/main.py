import scapy.all as scapy
from ruamel.yaml import YAML
from ruamel.yaml.scalarstring import LiteralScalarString

#! Treba spravit extr subor pre L2 a L1 a nacitanie do Dict dole

ETHER_TYPES = {
    2048: "Internet IP (IPv4)",
    2049: "X.75 Internet",
    2053: "X.25 Level 3",
    2054: "ARP (Address Resolution Protocol)",
    32821: "Reverse ARP",
    32923: "Appletalk",
    33011: "AppleTalk AARP (Kinetics)",
    33024: "IEEE 802.1Q VLAN-tagged frames",
    33079: "Novell IPX",
    34525: "IPv6",
    34827: "PPP",
    34887: "MPLS",
    34888: "MPLS wit upstream-assigned label",
    34915: "PPPoE Discovery Stage",
    34916: "PPPoE Session Stage",
    35020: "LLDP",
    36864: "Loopback (0x9000)",
}

SAPS = {
    0: "Null SAP",
    2: "LLC Sublayer Management / Individual",
    3: "LLC Sublayer Management / Group",
    6: "IP (DoD Internet Protocol)",
    14: "PROWAY (IEC 955) Network Management, Maintenance and Installation",
    66: "STP",
    78: "MMS (Manufacturing Message Service) EIA-RS 511",
    94: "ISI IP",
    126: "X.25 PLP (ISO 8208)",
    142: "PROWAY (IEC 955) Active Station List Maintenance",
    224: "IPX(Novell Netware)",
    244: "LAN Management",
    254: "ISO Network Layer Protocols",
}

IP_PROTOCOLS = {
    1: "ICMP",
    2: "IGMP",
    6: "TCP",
    9: "IGRP",
    17: "UDP",
    47: "GRE",
    50: "ESP",
    51: "AH",
    57: "SKIP",
    88: "EIGRP",
    89: "OSPF",
    115: "L2TP",
}

IEEE_PID = {
    267: 'PVSTP+',
    768: 'XEROX NS IDP',
    8192: 'CDP',
    8196: 'DTP',
    12320: 'VTP',
    32923: 'Appletalk',
    33011: 'Apple Talk AARP'
}


def analyze_eth_packet(number, pckt):
    eth_packet = {
            'frame_number': number,
            'len_frame_pcap': '',
            'len_frame_medium': '',
            'frame_type': '',
            'src_mac': '',
            'dst_mac': '',
        }



    for pc in pckt:
        eth_packet['len_frame_pcap'] = len(pc)
        eth_packet['len_frame_medium'] = len(pc) + 4
        is_IEEE_type = int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[12:14]), 16) <= 1563
        
        if not is_IEEE_type: # Check if ETHERNET II or Not
            
            eth_packet['frame_type'] = 'ETHERNET II'
            eth_packet['src_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[6:12]).upper()
            eth_packet['dst_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[:6]).upper()
            #eth_packet['src_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[26:30])
            #eth_packet['dst_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[30:34])           
            # eth_packet['ether_type'] = ETHER_TYPES.get(int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[12:14]), 16))
            # eth_packet['protocol'] = IP_PROTOCOLS.get(int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[23:24]), 16))
            #eth_packet['src_port'] = int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[34:36]), 16)
            #eth_packet['dst_port'] = int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[36:38]), 16)
            eth_packet['hexa_frame'] = format_for_yaml(str(pc.__bytes__().hex()))
        
        else: # If not Eth II then check for Novell and IEEE
            
            has_Snap = ''.join(f'{byte:02x}' for byte in pc.__bytes__()[14:16]) == 'aaaa'
            is_Novell = ''.join(f'{byte:02x}' for byte in pc.__bytes__()[14:16]) == 'ffff'
            if is_Novell:
                eth_packet['frame_type'] = 'IEEE 802.3 RAW'
                eth_packet['src_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[6:12]).upper()
                eth_packet['dst_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[:6]).upper()
                # eth_packet['src_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[26:30])
                # eth_packet['dst_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[30:34])             
                eth_packet['hexa_frame'] = format_for_yaml(str(pc.__bytes__().hex()))
                    
            else: # If not IEE RAW then check for LLC or LLC + SNAP
                
                if has_Snap:
                    eth_packet['frame_type'] = 'IEEE 802.3 LLC & SNAP'
                    eth_packet['src_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[6:12]).upper()
                    eth_packet['dst_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[:6]).upper()
                    # eth_packet['src_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[26:30])
                    # eth_packet['dst_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[30:34])
                    if IEEE_PID.get(int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[20:22]), 16), "Unknown") != "Unknown":
                        eth_packet['pid'] = IEEE_PID.get(int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[20:22]), 16), "Unknown")
                        # print(int(''.join(f'{byte:02x}' for byte in pc.__bytes__()[20:22]), 16))
                    eth_packet['hexa_frame'] = format_for_yaml(str(pc.__bytes__().hex()))
                else:
                    eth_packet['frame_type'] = 'IEEE 802.3 LLC'
                    eth_packet['src_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[6:12]).upper()
                    eth_packet['dst_mac'] = ':'.join(f'{byte:02x}' for byte in pc.__bytes__()[:6]).upper()
                    # eth_packet['src_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[26:30])
                    # eth_packet['dst_ip'] = '.'.join(str(byte) for byte in pc.__bytes__()[30:34])
                    eth_packet['sap'] = SAPS.get(int(pc.__bytes__()[15]), 16)
                    eth_packet['hexa_frame'] = format_for_yaml(str(pc.__bytes__().hex()))
        
        return eth_packet

def analyze_pcap(data):
    """function for analyzing each packet from the pcap file

    Args:
        data (.pcap): tcp/dump in .pcap format

    Returns:
        list: list of all captured and formated frames
    """
    datapcap = scapy.rdpcap(data)
    frame_number = 1
    frames = []
    for pc in datapcap:
        frames.append(analyze_eth_packet(frame_number, pc))
        frame_number += 1
    
    return frames

def format_for_yaml(hex_string):
    """Function for formatting the HEX FRAME for YAML

    Args:
        hex_string (str): hex data in string format for easier formatting

    Returns:
        list: List of Parsed hex to 16 bytes 
    """
    formatted_hex_dump = []
    for i in range(0, len(hex_string)):
        if i > 0 and i % 32 == 0:
            formatted_hex_dump.append("\n")

        formatted_hex_dump.append(hex_string[i])

        if i != len(hex_string) - 1 and i % 32 != 31 and i % 2 == 1:
            formatted_hex_dump.append(" ")
    formatted_hex_dump.append("\n")
    formatted_hex_dump = LiteralScalarString("".join(formatted_hex_dump).upper())
    return formatted_hex_dump

if __name__ == '__main__':
    print("STARTING")
    filename = './Vzor/test_pcap_files/vzorky_pcap_na_analyzu/trace-26.pcap'
    # filename = './data.pcap'
    pcap_data = analyze_pcap(filename)
    
    yaml = YAML()
    with open('output.yaml', 'w') as f:
        
        yaml.dump(
            {"name":'PKS2023/24',
             "pcap_name": filename ,
             "packets": pcap_data }
            , f)
    f.close()
    print('DONE')